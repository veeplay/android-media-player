/** Automatically generated file. DO NOT MODIFY */
package com.appscend.vastplayer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}